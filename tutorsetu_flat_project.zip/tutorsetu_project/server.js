const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, 'tutorsetu.db'));
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tutors (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, qualification TEXT, subjects TEXT, classes TEXT, experience TEXT, area TEXT, fee INTEGER NOT NULL DEFAULT 0, mode TEXT DEFAULT 'Home Tuition', photo TEXT, published INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS requests (id INTEGER PRIMARY KEY AUTOINCREMENT, parent_name TEXT NOT NULL, mobile TEXT NOT NULL, child_class TEXT, subject TEXT, area TEXT, timing TEXT, requirement TEXT, tutor_id INTEGER, demo INTEGER DEFAULT 0, status TEXT DEFAULT 'New', created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(tutor_id) REFERENCES tutors(id));
`);
if (!db.prepare('SELECT id FROM admins LIMIT 1').get()) {
  const username = process.env.ADMIN_USERNAME || 'admin';
  const password = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
  db.prepare('INSERT INTO admins (username,password_hash) VALUES (?,?)').run(username, bcrypt.hashSync(password, 12));
  console.log(`Initial admin created: ${username}. Change the password before production.`);
}

app.use(express.json({limit:'1mb'}));
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || 'CHANGE_THIS_SESSION_SECRET',
  resave:false,
  saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:'lax', secure:process.env.NODE_ENV==='production', maxAge:1000*60*60*8}
}));
app.use('/uploads', express.static(uploadDir));
app.use(express.static(__dirname));

function adminOnly(req,res,next){ if(req.session.adminId) return next(); res.status(401).json({error:'Admin login required'}); }
function clean(v){ return typeof v==='string' ? v.trim() : ''; }

app.post('/api/login',(req,res)=>{
  const username=clean(req.body.username), password=String(req.body.password||'');
  const admin=db.prepare('SELECT * FROM admins WHERE username=?').get(username);
  if(!admin || !bcrypt.compareSync(password,admin.password_hash)) return res.status(401).json({error:'Invalid username or password'});
  req.session.adminId=admin.id; res.json({ok:true});
});
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me',(req,res)=>res.json({authenticated:!!req.session.adminId}));

app.get('/api/tutors',(req,res)=>{
  const rows=db.prepare('SELECT id,name,qualification,subjects,classes,experience,area,fee,mode,photo,published FROM tutors WHERE published=1 ORDER BY id DESC').all();
  res.json(rows);
});
app.get('/api/tutors/all',adminOnly,(req,res)=>res.json(db.prepare('SELECT * FROM tutors ORDER BY id DESC').all()));

const tutorFields=['name','qualification','subjects','classes','experience','area','fee','mode','published'];
function tutorPayload(b){
  const out={}; tutorFields.forEach(k=>out[k]=k==='fee'||k==='published'?Number(b[k]||0):clean(b[k]));
  if(!out.name) throw new Error('Tutor name is required');
  if(out.fee<0) throw new Error('Fee cannot be negative');
  out.published=out.published?1:0; return out;
}
app.post('/api/tutors',adminOnly,(req,res)=>{try{const t=tutorPayload(req.body); const r=db.prepare(`INSERT INTO tutors (${tutorFields.join(',')}) VALUES (${tutorFields.map(x=>'?').join(',')})`).run(tutorFields.map(x=>t[x])); res.json({id:r.lastInsertRowid});}catch(e){res.status(400).json({error:e.message});}});
app.put('/api/tutors/:id',adminOnly,(req,res)=>{try{const t=tutorPayload(req.body); db.prepare(`UPDATE tutors SET ${tutorFields.map(x=>`${x}=?`).join(',')} WHERE id=?`).run(...tutorFields.map(x=>t[x]),req.params.id); res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
app.delete('/api/tutors/:id',adminOnly,(req,res)=>{db.prepare('DELETE FROM tutors WHERE id=?').run(req.params.id);res.json({ok:true});});

const storage=multer({storage:multer.diskStorage({destination:uploadDir,filename:(req,file,cb)=>{const ext=path.extname(file.originalname).toLowerCase(); cb(null,`tutor-${req.params.id}-${Date.now()}${ext}`);}}),limits:{fileSize:3*1024*1024},fileFilter:(req,file,cb)=>cb(null,/^image\/(jpeg|png|webp)$/.test(file.mimetype))});
app.post('/api/tutors/:id/photo',adminOnly,storage.single('photo'),(req,res)=>{if(!req.file)return res.status(400).json({error:'Please upload a JPG, PNG or WebP image'});const photo='/uploads/'+req.file.filename;db.prepare('UPDATE tutors SET photo=? WHERE id=?').run(photo,req.params.id);res.json({photo});});

app.post('/api/requests',(req,res)=>{const b=req.body; const vals=[clean(b.parent_name),clean(b.mobile),clean(b.child_class),clean(b.subject),clean(b.area),clean(b.timing),clean(b.requirement),b.tutor_id?Number(b.tutor_id):null,b.demo?1:0]; if(!vals[0]||!vals[1])return res.status(400).json({error:'Parent name and mobile are required'}); const r=db.prepare('INSERT INTO requests (parent_name,mobile,child_class,subject,area,timing,requirement,tutor_id,demo) VALUES (?,?,?,?,?,?,?,?,?)').run(...vals);res.json({ok:true,id:r.lastInsertRowid});});
app.get('/api/requests',adminOnly,(req,res)=>res.json(db.prepare(`SELECT r.*, t.name AS tutor_name FROM requests r LEFT JOIN tutors t ON t.id=r.tutor_id ORDER BY r.id DESC`).all()));
app.patch('/api/requests/:id',adminOnly,(req,res)=>{const status=['New','Contacted','Assigned','Completed','Cancelled'].includes(req.body.status)?req.body.status:'New';db.prepare('UPDATE requests SET status=? WHERE id=?').run(status,req.params.id);res.json({ok:true});});

app.get('/admin',(req,res)=>res.sendFile(path.join(__dirname,'admin.html')));
app.listen(PORT,()=>console.log(`TutorSetu running on http://localhost:${PORT}`));
